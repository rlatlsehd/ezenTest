package com.fish.myapp.persistence;

import java.util.ArrayList;
import java.util.HashMap;

import com.fish.myapp.domain.BoardVo;

public interface BoardService_Mapper {
	
	//���̹�Ƽ���� ����� �޼ҵ带 �����Ѵ�
	public ArrayList<BoardVo> boardSelectAll();

	public BoardVo boardSelectOne(int bidx);
	
	public int boardInsert(HashMap<String,Object> hm);

	public int boardModify(HashMap<String, Object> hm);

	public int boardDelete(HashMap<String, Object> hm);

	public ArrayList<BoardVo> boardTopList();


}
