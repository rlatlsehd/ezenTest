package com.fish.myapp.persistence;

import java.util.ArrayList;
import java.util.HashMap;

import com.fish.myapp.domain.MemberVo;

public interface MemberService_Mapper {

	int memberJoin(HashMap<String, Object> hm);

	int memberModify(HashMap<String, Object> hm);

	int memberDelete(HashMap<String, Object> hm);

	MemberVo memberLogin(String memberid, String memberpwd);

	MemberVo memberCheckId(String membername, String memberphone);		

}
