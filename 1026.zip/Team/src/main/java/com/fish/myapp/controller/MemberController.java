package com.fish.myapp.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.fish.myapp.domain.MemberVo;
import com.fish.myapp.service.MemberService;

@Controller
public class MemberController {
	
	@Autowired
	MemberService ms;
	
	@RequestMapping(value = "/member/membertest.do")
	public String board() {		
		
		return "member/membertest";
		
	}
	
	@RequestMapping(value = "/member/memberJoin.do")
	public String boardWrite() {
		
		return "/member/memberJoin";
	}
	
	@RequestMapping(value = "/member/memberJoinAction.do")
	public String memberJoinAction(
			@RequestParam("id") String id,
			@RequestParam("pwd") String pwd,
			@RequestParam("name") String name,
			@RequestParam("gender") String gender,
			@RequestParam("phone") String phone
			) {		
		
		int result = ms.memberJoin(id, pwd, name, gender, phone);
		
		return "index1";
	}	
	
	@RequestMapping(value="/member/memberLogin.do")
	public String memberLogin() {			
		
		return "member/memberLogin";
	}
	
	@RequestMapping(value="/member/memberLoginAction.do")
	public String memberLoginAction(
			@RequestParam("memberid") String memberid,
			@RequestParam("memberpwd") String memberpwd,
			Model model) {
		System.out.println("");
		MemberVo mv = ms.memberLogin(memberid, memberpwd);
	//	System.out.println("id:"+mv.getMemberid());				
		String path =null;
		if (mv == null) {
			path = "redirect:/member/memberLogin.do";
		}else {
			model.addAttribute("memberid", mv.getMemberid());
			
		//	HttpSession session = request.getSession();
		//	session.setAttribute("id", mv.getMemberid());			
			
			path ="index1";
		}
		return path;
	}
	
	@RequestMapping(value="/member/memberCheckId.do")
	public String memberCheckId() {				
		
		return "member/memberCheckId";
	}
	
	@RequestMapping(value="/member/memberCheckIdAction.do")
	public String memberCheckIdAction(
			@RequestParam("membername") String membername,
			@RequestParam("memberphone") String memberphone,
			Model model) {
		System.out.println("");
		MemberVo mv = ms.memberCheckId(membername, memberphone);
	//	System.out.println("id:"+mv.getMemberid());				
		String path =null;
		
		if (mv == null) {
			path = "redirect:/member/memberCheckId.do";
		}else {
			model.addAttribute("memberid", mv.getMemberid());
			
		//	HttpSession session = request.getSession();
		//	session.setAttribute("id", mv.getMemberid());			
			
			path ="redirect:/member/memberCheckIdResult.do";
		}
		return path;
	}
	
	@RequestMapping(value = "/member/memberModifyAction.do")
	public String memberModifyAction() {
		
		int midx = 2;
		String Id = "xowns0537";
		String password = "���";
		String name = "�̸�";
		String birth = "1996-01-01";
		String gender = "F";
		String email = "ezen@naver.com";
		String phone = "010-1234-5678";
		int age = 26;
		String address = "����";		
		
		int result = ms.memberModify(midx, Id, password, name, birth, gender, email, phone, age, address);
		
		return "redirect:/";
	}
	
	@RequestMapping(value = "/member/memberDeleteAction.do")
	public String memberDeleteAction() {
		
		int midx = 2;		
		int result = ms.memberDelete(midx);
		
		return "redirect:/";
	}
	
	
}
