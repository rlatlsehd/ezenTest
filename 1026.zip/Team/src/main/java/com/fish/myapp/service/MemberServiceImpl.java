package com.fish.myapp.service;

import java.util.HashMap;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fish.myapp.domain.MemberVo;
import com.fish.myapp.persistence.BoardService_Mapper;
import com.fish.myapp.persistence.MemberService_Mapper;

@Service("MemberServiceImpl")
public class MemberServiceImpl implements MemberService{

	@Autowired
	SqlSession sqlSession;

	@Override
	public int memberJoin(String id, String password, String name, String gender, String phone) {
		HashMap<String,Object> hm = new HashMap<String,Object>();
		hm.put("id", id);
		hm.put("password", password);
		hm.put("name", name);
		hm.put("gender", gender);		
		hm.put("phone", phone);		
		
		MemberService_Mapper msm = sqlSession.getMapper(MemberService_Mapper.class);
		int result = msm.memberJoin(hm);
		
		return result;
	}

	@Override
	public MemberVo memberLogin(String memberid, String memberpwd) {
		MemberService_Mapper msm = sqlSession.getMapper(MemberService_Mapper.class);
		MemberVo mv = msm.memberLogin(memberid, memberpwd);		
		System.out.println(mv.getMemberid());
		
		return mv;
	}
	

	@Override
	public MemberVo memberCheckId(String membername, String memberphone) {
		MemberService_Mapper msm = sqlSession.getMapper(MemberService_Mapper.class);
		MemberVo mv = msm.memberCheckId(membername, memberphone);		
		System.out.println(mv.getMemberid());
		
		return mv;
	}

	
	@Override
	public int memberModify(int midx, String Id, String password, String name, String birth, String gender,
			String email, String phone, int age, String address) {
		HashMap<String,Object> hm = new HashMap<String,Object>();
		hm.put("midx", midx);
		hm.put("Id", Id);
		hm.put("password", password);
		hm.put("name", name);
		hm.put("birth", birth);		
		hm.put("gender", gender);		
		hm.put("email", email);		
		hm.put("phone", phone);		
		hm.put("age", age);		
		hm.put("address", address);		
		
		MemberService_Mapper msm = sqlSession.getMapper(MemberService_Mapper.class);
		int result = msm.memberModify(hm);
		
		return result;
	}

	@Override
	public int memberDelete(int midx) {
		HashMap<String,Object> hm = new HashMap<String,Object>();
		hm.put("midx", midx);
		

		MemberService_Mapper msm = sqlSession.getMapper(MemberService_Mapper.class);
		int result = msm.memberDelete(hm);
		
		return result;
	}

}
