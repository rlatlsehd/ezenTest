package com.fish.myapp.service;

import java.util.ArrayList;

import com.fish.myapp.domain.BoardVo;

public interface BoardService {

	public ArrayList<BoardVo> boardSelectAll();
	
	public BoardVo boardSelectOne(int bidx);
	
	public int boardInsert(String title,String content, String writer, String pwd);

	public int boardModify(int bidx, String title, String content, String writer, String pwd);

	public int boardDelete(int bidx);

	public ArrayList<BoardVo> boardTopList();
	
}
